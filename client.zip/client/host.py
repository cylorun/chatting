API_ADDR = ' https://9c29d83b6fdf.ngrok.app' #'http://localhost:3030'
SOCKET_ADDR = ('0.tcp.eu.ngrok.io',13873)#('localhost',5555)

